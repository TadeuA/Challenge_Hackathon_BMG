import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  FlatList,
  StyleSheet,
} from "react-native";

import * as ActionsLevel from "../store/actions/level";

import options from "../configs/options";

import { connect } from "react-redux";

const Nivel = (toggleLevel) => {
  return (
    <>
      <Text style={styles.tittle}>Maravilha!</Text>
      <Text style={styles.tittle}>DAgora, escolha uma opção</Text>

      <View>
        <TouchableOpacity onPress={() => {}}  style={styles.containerOption}>
          <View  style={styles.containerOptionSelect}>
            <Image source={options("noob")} />
            <View  style={styles.containerText}>
                <Text style={styles.containerOptionTittle}>Novo(a) nesse assunto?</Text>
                <Text style={styles.containerOptionText}>Comece aqui pelo básico</Text>
            </View>
          </View>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => {}} style={styles.containerOption}>
          <View  style={styles.containerOptionSelect}>
            <Image source={options("expert")} />
            <View  style={styles.containerText}>
                <Text style={styles.containerOptionTittle}>Já possuo conhecimento prévio!</Text>
                <Text style={styles.containerOptionText}>
                Teste aqui seu conhecimento para iniciar da maneira que fizer
                sentido para você
                </Text>
            </View>
          </View>
        </TouchableOpacity>
      </View>
    </>
  );
};

const mapStateToProps = (state) => ({});
const mapDispatchToProps = (dispatch) => ({
  toggleLevel: (level) => dispatch(ActionsLevel.togglesNivel(level)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Nivel);

const styles = StyleSheet.create({
  container: {},
  tittle:{
    paddingHorizontal: 10,
    color: "#F58220",
    fontSize: 25,
    paddingBottom:5,
  },
  containerOption:{
      margin:25,
      borderRadius:20,
      flexDirection:'row',
      padding:15,
      borderWidth:3,
      borderColor:'#C4C4C4',
  },
  containerOptionSelect:{
      flexDirection:'row',
      justifyContent:'space-between',
      padding:10,
  },
  containerOptionTittle:{
    fontSize:20,
    color:'#525252',
    fontWeight:'bold',
   
  },
  containerText:{
    flexDirection:'column',
    maxWidth:"80%",
     paddingLeft:15,
  },
  containerOptionText:{
    fontSize:12,
    color:'#525252',
  }

});
